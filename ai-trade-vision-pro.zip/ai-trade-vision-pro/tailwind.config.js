/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: '#0a0e1a',
          card: '#0d1221',
          panel: '#111827',
        },
        neon: {
          green: '#00ff88',
          blue: '#00aaff',
          red: '#ff3b5c',
          gold: '#ffd700',
          purple: '#a855f7',
        },
        border: {
          DEFAULT: '#1e2d47',
          glow: '#00ff8844',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      animation: {
        'pulse-green': 'pulse-green 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scan': 'scan 2s linear infinite',
        'glow': 'glow 1.5s ease-in-out infinite alternate',
        'ticker': 'ticker 30s linear infinite',
        'fadeIn': 'fadeIn 0.3s ease-in',
        'slideUp': 'slideUp 0.4s ease-out',
      },
      keyframes: {
        'pulse-green': {
          '0%, 100%': { opacity: '1', boxShadow: '0 0 8px #00ff88' },
          '50%': { opacity: '0.6', boxShadow: '0 0 0px #00ff88' },
        },
        'scan': {
          '0%': { backgroundPosition: '0% 0%' },
          '100%': { backgroundPosition: '0% 100%' },
        },
        'glow': {
          from: { textShadow: '0 0 4px #00ff88, 0 0 8px #00ff8844' },
          to: { textShadow: '0 0 8px #00ff88, 0 0 20px #00ff8888' },
        },
        'ticker': {
          '0%': { transform: 'translateX(100%)' },
          '100%': { transform: 'translateX(-100%)' },
        },
        'fadeIn': {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        'slideUp': {
          from: { opacity: '0', transform: 'translateY(16px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
      backgroundImage: {
        'cyber-grid': "linear-gradient(rgba(0,255,136,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,136,0.03) 1px, transparent 1px)",
        'card-shine': "linear-gradient(135deg, rgba(255,255,255,0.03) 0%, transparent 50%)",
      },
      backgroundSize: {
        'grid': '40px 40px',
      },
    },
  },
  plugins: [],
}
