import { useState, useEffect, useCallback, useRef } from 'react'
import { generateCandles, simulateMarketData, PAIRS } from '../utils/chartUtils'

export function useMarket(selectedPair, timeframe) {
  const [candles, setCandles] = useState([])
  const [price, setPrice]     = useState(0)
  const [change, setChange]   = useState(0)
  const [market, setMarket]   = useState([])
  const tickRef = useRef(null)

  // Init market data once
  useEffect(() => {
    setMarket(simulateMarketData())
  }, [])

  // Regenerate candles on pair / timeframe change
  useEffect(() => {
    const found = PAIRS.find(p => p.symbol === selectedPair)
    const base  = found?.base ?? 65000
    const vol   = base < 1 ? 0.025 : base < 100 ? 0.018 : 0.012
    const newCandles = generateCandles(80, base, vol)
    setCandles(newCandles)
    const last = newCandles[newCandles.length - 1]
    setPrice(last.close)
    const pct = ((last.close - newCandles[0].open) / newCandles[0].open) * 100
    setChange(parseFloat(pct.toFixed(2)))
  }, [selectedPair, timeframe])

  // Live tick updates
  useEffect(() => {
    tickRef.current = setInterval(() => {
      setCandles(prev => {
        if (!prev.length) return prev
        const last  = prev[prev.length - 1]
        const found = PAIRS.find(p => p.symbol === selectedPair)
        const base  = found?.base ?? 65000
        const vol   = base < 1 ? 0.025 : base < 100 ? 0.018 : 0.012
        const move  = (Math.random() - 0.48) * last.close * vol * 0.5
        const newClose = Math.max(last.close + move, last.close * 0.5)
        const updated  = [
          ...prev.slice(-79),
          {
            ...last,
            close: newClose,
            high: Math.max(last.high, newClose),
            low:  Math.min(last.low,  newClose),
          },
        ]
        setPrice(newClose)
        return updated
      })
    }, 1500)

    return () => clearInterval(tickRef.current)
  }, [selectedPair])

  return { candles, price, change, market }
}
