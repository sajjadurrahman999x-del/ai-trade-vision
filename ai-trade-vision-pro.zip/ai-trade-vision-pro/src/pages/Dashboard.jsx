import { useState } from 'react'
import { useMarket } from '../hooks/useMarket'
import { TIMEFRAMES, formatPrice } from '../utils/chartUtils'
import { analyzeLiveChart, mockAnalysis } from '../utils/aiService'
import CandleChart from '../components/CandleChart'
import MarketSidebar from '../components/MarketSidebar'
import AnalysisResult from '../components/AnalysisResult'

const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY

export default function Dashboard() {
  const [selectedPair, setSelectedPair] = useState('BTC/USDT')
  const [tf, setTf]                     = useState('1h')
  const [analysis, setAnalysis]         = useState(null)
  const [loading, setLoading]           = useState(false)

  const { candles, price, change, market } = useMarket(selectedPair, tf)

  const handleAnalyze = async () => {
    setLoading(true)
    setAnalysis(null)
    try {
      const result = API_KEY
        ? await analyzeLiveChart(candles, selectedPair, tf)
        : mockAnalysis(selectedPair, price)
      setAnalysis(result)
    } catch {
      setAnalysis(mockAnalysis(selectedPair, price))
    }
    setLoading(false)
  }

  return (
    <div className="flex flex-col md:flex-row gap-4 p-4 min-h-screen cyber-bg">
      {/* Sidebar */}
      <div className="md:w-56 shrink-0">
        <MarketSidebar market={market} selectedPair={selectedPair} onSelect={p => { setSelectedPair(p); setAnalysis(null) }} />

        {/* Fear & Greed */}
        <div className="card mt-4 text-center">
          <div className="metric-label">Fear & Greed</div>
          <div className="text-4xl font-bold text-neon-gold mt-2">72</div>
          <div className="text-slate-400 text-xs mt-1">Greed</div>
          <div className="h-2 rounded-full mt-3 overflow-hidden" style={{ background: '#1a2235' }}>
            <div
              className="h-full rounded-full"
              style={{ width: '72%', background: 'linear-gradient(90deg, #00ff88, #ffd700, #ff3b5c)' }}
            />
          </div>
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col gap-4">
        {/* Chart card */}
        <div
          className="card"
          style={{ boxShadow: '0 0 16px rgba(0,255,136,0.06)', borderColor: 'rgba(0,255,136,0.2)' }}
        >
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-3">
              <span className="font-bold text-base">{selectedPair}</span>
              <span
                className="font-bold text-xl font-mono"
                style={{ color: change >= 0 ? '#00ff88' : '#ff3b5c' }}
              >
                ${formatPrice(price, selectedPair)}
              </span>
              <span
                className="text-sm font-semibold"
                style={{ color: change >= 0 ? '#00ff88' : '#ff3b5c' }}
              >
                {change >= 0 ? '▲' : '▼'} {Math.abs(change)}%
              </span>
            </div>
            <div className="flex gap-1.5">
              {TIMEFRAMES.map(t => (
                <button
                  key={t}
                  onClick={() => setTf(t)}
                  className="px-2.5 py-1 rounded text-xs transition-all duration-150"
                  style={{
                    border: `1px solid ${tf === t ? '#00aaff' : '#1e2d47'}`,
                    background: tf === t ? 'rgba(0,170,255,0.15)' : 'transparent',
                    color: tf === t ? '#00aaff' : '#64748b',
                    cursor: 'pointer',
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <CandleChart candles={candles} width={800} height={300} />

          <div className="flex items-center justify-between mt-3 flex-wrap gap-2">
            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="btn-primary"
              style={{ opacity: loading ? 0.7 : 1, cursor: loading ? 'wait' : 'pointer' }}
            >
              {loading ? '⟳ Analyzing...' : '⚡ AI Analyze Chart'}
            </button>
            <span className="text-slate-500 text-xs">Live · updates every 1.5s</span>
          </div>
        </div>

        {/* Analysis result */}
        {analysis && (
          <AnalysisResult
            analysis={{ ...analysis, asset: selectedPair, timeframe: tf }}
            onReset={() => setAnalysis(null)}
          />
        )}
      </div>
    </div>
  )
}
