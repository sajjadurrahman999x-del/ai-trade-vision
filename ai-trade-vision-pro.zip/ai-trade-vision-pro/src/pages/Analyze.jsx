import { useState, useRef, useCallback } from 'react'
import { analyzeChartImage, mockAnalysis } from '../utils/aiService'
import AnalysisResult from '../components/AnalysisResult'

const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY

export default function Analyze() {
  const [dragging, setDragging]     = useState(false)
  const [imgUrl, setImgUrl]         = useState(null)
  const [imgB64, setImgB64]         = useState(null)
  const [imgType, setImgType]       = useState('image/jpeg')
  const [loading, setLoading]       = useState(false)
  const [progress, setProgress]     = useState(0)
  const [progressMsg, setProgressMsg] = useState('')
  const [analysis, setAnalysis]     = useState(null)
  const fileRef                     = useRef(null)

  const MESSAGES = [
    'Scanning candlestick patterns...',
    'Analyzing market structure...',
    'Detecting support & resistance...',
    'Computing probabilities...',
    'Generating AI signals...',
  ]

  const loadFile = useCallback((file) => {
    if (!file || !file.type.startsWith('image/')) return
    setImgUrl(URL.createObjectURL(file))
    setImgType(file.type || 'image/jpeg')
    setAnalysis(null)
    const reader = new FileReader()
    reader.onload = (ev) => setImgB64(ev.target.result.split(',')[1])
    reader.readAsDataURL(file)
  }, [])

  const onDrop = useCallback((e) => {
    e.preventDefault()
    setDragging(false)
    loadFile(e.dataTransfer?.files[0])
  }, [loadFile])

  const onFileInput = useCallback((e) => loadFile(e.target.files[0]), [loadFile])

  const handleAnalyze = async () => {
    if (!imgB64) return
    setLoading(true)
    setProgress(0)
    let step = 0
    setProgressMsg(MESSAGES[0])
    const tick = setInterval(() => {
      setProgress(p => {
        const next = Math.min(p + Math.random() * 18, 92)
        step = Math.min(Math.floor(next / 20), MESSAGES.length - 1)
        setProgressMsg(MESSAGES[step])
        return next
      })
    }, 380)
    try {
      const result = API_KEY
        ? await analyzeChartImage(imgB64, imgType)
        : mockAnalysis('Chart', 0)
      clearInterval(tick)
      setProgress(100)
      setTimeout(() => { setAnalysis(result); setLoading(false) }, 500)
    } catch {
      clearInterval(tick)
      setLoading(false)
      setAnalysis(mockAnalysis('Chart', 0))
    }
  }

  const reset = () => {
    setImgUrl(null); setImgB64(null); setAnalysis(null); setProgress(0)
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <div className="mb-5">
        <h1 className="text-neon-green font-bold text-lg">📸 AI Chart Screenshot Analysis</h1>
        <p className="text-slate-400 text-xs mt-1">
          Upload any trading chart — BTC, ETH, Forex, Gold, Stocks, Indices, Options
        </p>
      </div>

      {/* Drop zone */}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={onFileInput}
      />
      <div
        onClick={() => !imgUrl && fileRef.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className="relative rounded-xl overflow-hidden transition-all duration-300 cursor-pointer"
        style={{
          border: `2px dashed ${dragging ? '#00ff88' : imgUrl ? '#1e2d47' : '#1e2d47'}`,
          background: dragging ? 'rgba(0,255,136,0.04)' : '#0d1221',
          boxShadow: dragging ? '0 0 20px rgba(0,255,136,0.15)' : 'none',
          minHeight: imgUrl ? 'auto' : 200,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: imgUrl ? 0 : 40,
        }}
      >
        {imgUrl ? (
          <div className="relative w-full">
            <img
              src={imgUrl}
              alt="Uploaded chart"
              className="w-full rounded-xl object-contain"
              style={{ maxHeight: 400 }}
            />
            {loading && (
              <div
                className="absolute inset-0 flex flex-col items-center justify-center rounded-xl gap-3"
                style={{ background: 'rgba(8,12,24,0.85)' }}
              >
                <div className="scan-line" style={{ position: 'absolute', left: 0, right: 0, height: 2 }} />
                <div className="text-neon-green font-semibold text-sm">{progressMsg}</div>
                <div className="w-64 h-2 rounded-full overflow-hidden" style={{ background: '#1a2235' }}>
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${progress}%`,
                      background: 'linear-gradient(90deg, #00aaff, #00ff88)',
                      boxShadow: '0 0 8px #00ff8888',
                    }}
                  />
                </div>
                <div className="text-slate-500 text-xs">{progress.toFixed(0)}%</div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center">
            <div className="text-5xl mb-3">📊</div>
            <div className="text-slate-200 font-semibold mb-1.5">
              {dragging ? 'Drop it!' : 'Drop chart screenshot here'}
            </div>
            <div className="text-slate-500 text-xs mb-4">
              or click to browse · mobile camera supported
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {['BTC', 'ETH', 'Forex', 'Gold', 'Stocks', 'Indices'].map(t => (
                <span key={t} className="pattern-tag">{t}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Action buttons */}
      {imgUrl && !loading && !analysis && (
        <div className="flex gap-3 mt-4 justify-center">
          <button onClick={handleAnalyze} className="btn-primary px-8">
            🤖 Run AI Analysis
          </button>
          <button onClick={reset} className="btn-outline">
            ✕ Remove
          </button>
        </div>
      )}

      {/* No API key notice */}
      {!API_KEY && (
        <div
          className="mt-3 p-3 rounded-lg text-xs text-center"
          style={{ background: 'rgba(0,170,255,0.08)', border: '1px solid rgba(0,170,255,0.2)', color: '#64a0c0' }}
        >
          ℹ️ Demo mode — add <code className="font-mono">VITE_ANTHROPIC_API_KEY</code> in <code className="font-mono">.env</code> for real AI analysis
        </div>
      )}

      {/* Result */}
      {analysis && <AnalysisResult analysis={analysis} onReset={reset} />}
    </div>
  )
}
