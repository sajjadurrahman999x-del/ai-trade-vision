const PLANS = [
  {
    name: 'Free',
    price: '$0',
    period: '/mo',
    color: '#64748b',
    features: [
      '5 AI analyses per day',
      'Basic trading signals',
      '1 live chart pair',
      'Standard AI model',
      'Community support',
    ],
    cta: 'Get Started',
    featured: false,
  },
  {
    name: 'Pro',
    price: '$29',
    period: '/mo',
    color: '#00aaff',
    features: [
      'Unlimited AI analyses',
      'All trading signals',
      '8 live chart pairs',
      'Advanced AI model',
      'Telegram alerts',
      'Analysis history (30 days)',
      'Priority processing',
    ],
    cta: 'Upgrade to Pro',
    featured: true,
  },
  {
    name: 'VIP',
    price: '$79',
    period: '/mo',
    color: '#ffd700',
    features: [
      'Everything in Pro',
      'Real-time priority queue',
      'Multi-chart analysis',
      'Whale tracker alerts',
      'VIP Telegram group',
      'REST API access',
      'Custom indicators',
      'Dedicated support',
    ],
    cta: 'Go VIP',
    featured: false,
  },
]

export default function Pricing() {
  return (
    <div className="p-4 max-w-3xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-neon-green font-bold text-2xl">💎 Choose Your Plan</h1>
        <p className="text-slate-400 text-sm mt-2">
          Unlock the full power of AI trading intelligence
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {PLANS.map(plan => (
          <div
            key={plan.name}
            className="card flex flex-col relative"
            style={{
              borderColor: plan.featured ? plan.color : '#1e2d47',
              boxShadow: plan.featured ? `0 0 20px ${plan.color}22` : 'none',
            }}
          >
            {plan.featured && (
              <div
                className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold whitespace-nowrap"
                style={{ background: plan.color, color: '#000' }}
              >
                MOST POPULAR
              </div>
            )}

            <div className="text-center mb-4">
              <div className="font-bold text-base mb-2" style={{ color: plan.color }}>
                {plan.name}
              </div>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-3xl font-bold text-slate-100">{plan.price}</span>
                <span className="text-slate-400 text-sm">{plan.period}</span>
              </div>
            </div>

            <div className="flex-1 border-t border-border pt-4 mb-5">
              {plan.features.map(f => (
                <div key={f} className="flex items-start gap-2 py-1.5">
                  <span className="text-neon-green text-xs mt-0.5">✓</span>
                  <span className="text-slate-300 text-xs leading-snug">{f}</span>
                </div>
              ))}
            </div>

            <button
              className="w-full py-2.5 rounded-lg font-bold text-sm transition-all duration-200"
              style={{
                border: `1px solid ${plan.color}`,
                background: plan.featured ? plan.color : 'transparent',
                color: plan.featured ? '#000' : plan.color,
                cursor: 'pointer',
              }}
            >
              {plan.cta}
            </button>
          </div>
        ))}
      </div>

      {/* Feature comparison */}
      <div className="mt-8 card">
        <div className="metric-label mb-3">What's included in every plan</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            ['🔒', 'Secure Platform'],
            ['📱', 'Mobile PWA'],
            ['🌐', 'Multi-language'],
            ['📊', 'Live Charts'],
          ].map(([icon, label]) => (
            <div key={label} className="text-center py-3 rounded-lg" style={{ background: '#080c18' }}>
              <div className="text-2xl mb-1">{icon}</div>
              <div className="text-slate-400 text-xs">{label}</div>
            </div>
          ))}
        </div>
      </div>

      <div
        className="mt-5 p-3 rounded-lg text-xs text-center"
        style={{ background: '#0d1221', border: '1px solid #1e2d47', color: '#4a5568' }}
      >
        ⚠️ This platform provides AI-generated market analysis and does not guarantee financial accuracy.
        Trading involves significant risk and this is not financial advice. Never invest more than you can afford to lose.
      </div>
    </div>
  )
}
