import { useState } from 'react'
import { SignalBadge, ProbabilityBar, PatternTag } from '../components/AnalysisResult'

const MOCK_SIGNALS = [
  { pair:'BTC/USDT', tf:'4h', signal:'BUY',  conf:84, up:78, down:22, entry:'64,200', tp:'68,500', sl:'62,800', ago:'2m',  patterns:['Bull Flag','Golden Cross','Higher Highs'] },
  { pair:'ETH/USDT', tf:'1h', signal:'SELL', conf:71, up:29, down:71, entry:'3,180',  tp:'3,050',  sl:'3,240',  ago:'8m',  patterns:['Head & Shoulders','Lower High'] },
  { pair:'SOL/USDT', tf:'15m',signal:'BUY',  conf:65, up:62, down:38, entry:'178.5',  tp:'192',    sl:'172',    ago:'14m', patterns:['Bullish Engulfing','Demand Zone'] },
  { pair:'BNB/USDT', tf:'1D', signal:'HOLD', conf:55, up:52, down:48, entry:'418',    tp:'445',    sl:'395',    ago:'1h',  patterns:['Consolidation','Doji'] },
  { pair:'XRP/USDT', tf:'4h', signal:'BUY',  conf:72, up:69, down:31, entry:'0.61',   tp:'0.70',   sl:'0.58',   ago:'30m', patterns:['Ascending Triangle','Volume Spike'] },
  { pair:'ADA/USDT', tf:'1h', signal:'SELL', conf:61, up:35, down:65, entry:'0.479',  tp:'0.440',  sl:'0.498',  ago:'22m', patterns:['Bearish Divergence','Double Top'] },
]

const SIGNAL_COLORS = { BUY:'#00ff88', SELL:'#ff3b5c', HOLD:'#ffd700' }

export default function Signals() {
  const [filter, setFilter] = useState('ALL')

  const visible = filter === 'ALL'
    ? MOCK_SIGNALS
    : MOCK_SIGNALS.filter(s => s.signal === filter)

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div>
          <h1 className="text-neon-green font-bold text-lg">⚡ AI Trading Signals</h1>
          <p className="text-slate-400 text-xs mt-0.5">Real-time AI signals across pairs and timeframes</p>
        </div>
        <div className="flex gap-2">
          {['ALL','BUY','SELL','HOLD'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="px-3 py-1 rounded text-xs font-medium transition-all duration-150"
              style={{
                border: `1px solid ${filter === f ? (SIGNAL_COLORS[f] || '#00ff88') : '#1e2d47'}`,
                background: filter === f ? `${SIGNAL_COLORS[f] || '#00ff88'}18` : 'transparent',
                color: filter === f ? (SIGNAL_COLORS[f] || '#00ff88') : '#64748b',
                cursor: 'pointer',
              }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-3">
        {visible.map((sig, i) => (
          <div
            key={i}
            className="card animate-fadeIn"
            style={{
              boxShadow: `0 0 12px ${SIGNAL_COLORS[sig.signal]}18`,
              borderColor: `${SIGNAL_COLORS[sig.signal]}33`,
            }}
          >
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <SignalBadge signal={sig.signal} />
                <div>
                  <div className="font-bold text-sm">{sig.pair}</div>
                  <div className="text-slate-500 text-xs">{sig.tf} · {sig.ago} ago</div>
                </div>
              </div>

              <div className="flex gap-5 flex-wrap">
                {[['Entry', sig.entry, '#00aaff'], ['TP', sig.tp, '#00ff88'], ['SL', sig.sl, '#ff3b5c']].map(([k, v, c]) => (
                  <div key={k}>
                    <div className="text-slate-500 text-xs">{k}</div>
                    <div className="font-semibold text-sm" style={{ color: c }}>{v}</div>
                  </div>
                ))}
              </div>

              <div className="text-right">
                <div className="text-slate-500 text-xs">Confidence</div>
                <div className="text-neon-gold font-bold text-xl">{sig.conf}%</div>
              </div>
            </div>

            <div className="mt-3">
              <ProbabilityBar up={sig.up} down={sig.down} confidence={sig.conf} />
              <div className="mt-2">
                {sig.patterns.map(p => <PatternTag key={p} label={p} />)}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div
        className="mt-6 p-3 rounded-lg text-xs text-center"
        style={{ background: '#0d1221', border: '1px solid #1e2d47', color: '#4a5568' }}
      >
        ⚠️ AI-generated signals. Not financial advice. Always do your own research and manage risk appropriately.
      </div>
    </div>
  )
}
