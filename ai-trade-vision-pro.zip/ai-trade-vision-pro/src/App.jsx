import { Routes, Route } from 'react-router-dom'
import Navbar    from './components/Navbar'
import Dashboard from './pages/Dashboard'
import Analyze   from './pages/Analyze'
import Signals   from './pages/Signals'
import Pricing   from './pages/Pricing'

export default function App() {
  return (
    <div className="min-h-screen bg-bg-primary text-slate-200">
      <Navbar />
      <main>
        <Routes>
          <Route path="/"         element={<Dashboard />} />
          <Route path="/analyze"  element={<Analyze />}   />
          <Route path="/signals"  element={<Signals />}   />
          <Route path="/pricing"  element={<Pricing />}   />
          <Route path="*"         element={<Dashboard />} />
        </Routes>
      </main>
    </div>
  )
}
