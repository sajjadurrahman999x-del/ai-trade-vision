const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY
const MODEL   = 'claude-sonnet-4-20250514'

async function callClaude(messages, maxTokens = 1000) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, messages }),
  })
  if (!res.ok) throw new Error(`API error: ${res.status}`)
  const data = await res.json()
  const text = data.content?.map(b => b.text || '').join('') || '{}'
  return text.replace(/```json|```/g, '').trim()
}

// ─── Image Analysis ────────────────────────────────────────────────────────────

export async function analyzeChartImage(base64Image, mediaType = 'image/jpeg') {
  const prompt = `You are an expert professional trading analyst AI with deep knowledge of technical analysis. 
Analyze this trading chart image carefully and respond ONLY with valid JSON (no markdown, no extra text):
{
  "asset": "detected asset name or Unknown",
  "timeframe": "detected timeframe or Unknown",
  "trend": "BULLISH or BEARISH or SIDEWAYS",
  "signal": "BUY or SELL or HOLD",
  "upProbability": <integer 0-100>,
  "downProbability": <integer 0-100>,
  "confidence": <integer 0-100>,
  "riskLevel": <integer 0-100>,
  "entry": "price or zone as string",
  "stopLoss": "price or zone as string",
  "takeProfit": "price or zone as string",
  "patterns": ["pattern1", "pattern2"],
  "commentary": "2-3 sentence professional market analysis",
  "keyLevels": { "support": "level", "resistance": "level" },
  "indicators": { "rsi": "reading", "macd": "bullish/bearish/neutral", "volume": "high/low/normal" },
  "sentiment": "bullish/bearish/neutral",
  "timeHorizon": "short-term/medium-term/long-term"
}`

  const raw = await callClaude([{
    role: 'user',
    content: [
      { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64Image } },
      { type: 'text', text: prompt },
    ],
  }])

  return JSON.parse(raw)
}

// ─── Live Chart Analysis ───────────────────────────────────────────────────────

export async function analyzeLiveChart(candles, pair, timeframe) {
  const last = candles[candles.length - 1]
  const recent = candles.slice(-30)
  const closes = recent.map((c, i) => `${i}: ${c.close.toFixed(4)}`).join(', ')
  const highs = recent.map(c => c.high)
  const lows  = recent.map(c => c.low)

  const prompt = `You are an expert crypto trading AI analyst. Analyze this live ${pair} chart on ${timeframe} timeframe.

Data:
- Last 30 closes: ${closes}
- Current price: ${last.close.toFixed(4)}
- Recent high: ${Math.max(...highs).toFixed(4)}
- Recent low: ${Math.min(...lows).toFixed(4)}
- Volume trend: ${recent.slice(-5).map(c => c.volume.toFixed(0)).join(', ')}

Respond ONLY with valid JSON:
{
  "trend": "BULLISH or BEARISH or SIDEWAYS",
  "signal": "BUY or SELL or HOLD",
  "upProbability": <integer 0-100>,
  "downProbability": <integer 0-100>,
  "confidence": <integer 0-100>,
  "riskLevel": <integer 0-100>,
  "entry": "specific price",
  "stopLoss": "specific price",
  "takeProfit": "specific price",
  "patterns": ["pattern1", "pattern2"],
  "commentary": "2-3 sentence analysis",
  "keyLevels": { "support": "price", "resistance": "price" },
  "smartMoneyConcept": "brief SMC observation"
}`

  const raw = await callClaude([{ role: 'user', content: prompt }])
  return JSON.parse(raw)
}

// ─── Fallback (no API key) ────────────────────────────────────────────────────

export function mockAnalysis(pair = '', price = 0) {
  const signals = ['BUY', 'SELL', 'HOLD']
  const signal = signals[Math.floor(Math.random() * 3)]
  const up = Math.floor(Math.random() * 40 + 30)
  return {
    asset: pair || 'Unknown',
    timeframe: '1h',
    trend: up > 55 ? 'BULLISH' : up < 45 ? 'BEARISH' : 'SIDEWAYS',
    signal,
    upProbability: up,
    downProbability: 100 - up,
    confidence: Math.floor(Math.random() * 30 + 55),
    riskLevel: Math.floor(Math.random() * 40 + 20),
    entry: price ? price.toFixed(2) : 'N/A',
    stopLoss: price ? (price * 0.97).toFixed(2) : 'N/A',
    takeProfit: price ? (price * 1.05).toFixed(2) : 'N/A',
    patterns: ['Consolidation', 'Range bound', 'Pending breakout'],
    commentary: 'Demo mode: Add your VITE_ANTHROPIC_API_KEY in .env to enable real AI analysis.',
    keyLevels: { support: price ? (price * 0.95).toFixed(2) : 'N/A', resistance: price ? (price * 1.06).toFixed(2) : 'N/A' },
    indicators: { rsi: '52', macd: 'neutral', volume: 'normal' },
  }
}
