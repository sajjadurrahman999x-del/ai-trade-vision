// ─── Candle Generation ────────────────────────────────────────────────────────

export function generateCandles(count = 80, basePrice = 65000, volatility = 0.012) {
  const candles = []
  let price = basePrice
  let time = Date.now() - count * 60000
  let trend = Math.random() > 0.5 ? 1 : -1
  let trendStrength = 0

  for (let i = 0; i < count; i++) {
    if (Math.random() < 0.08) {
      trend *= -1
      trendStrength = 0
    }
    trendStrength = Math.min(trendStrength + 0.08, 1)

    const bias = trend * trendStrength * volatility * 0.35
    const open = price
    const move = (Math.random() - 0.5) * 2 * volatility + bias
    const close = open * (1 + move)
    const high = Math.max(open, close) * (1 + Math.random() * volatility * 0.4)
    const low = Math.min(open, close) * (1 - Math.random() * volatility * 0.4)
    const volume = Math.random() * 1200 + 300

    candles.push({ time, open, high, low, close, volume })
    price = close
    time += 60000
  }
  return candles
}

// ─── Technical Indicators ─────────────────────────────────────────────────────

export function calcEMA(candles, period = 20) {
  if (candles.length < period) return []
  const k = 2 / (period + 1)
  const result = []
  let ema = candles.slice(0, period).reduce((s, c) => s + c.close, 0) / period
  result.push({ time: candles[period - 1].time, value: ema })
  for (let i = period; i < candles.length; i++) {
    ema = candles[i].close * k + ema * (1 - k)
    result.push({ time: candles[i].time, value: ema })
  }
  return result
}

export function calcSMA(candles, period = 20) {
  const result = []
  for (let i = period - 1; i < candles.length; i++) {
    const sum = candles.slice(i - period + 1, i + 1).reduce((s, c) => s + c.close, 0)
    result.push({ time: candles[i].time, value: sum / period })
  }
  return result
}

export function calcRSI(candles, period = 14) {
  if (candles.length < period + 1) return []
  const gains = [], losses = []
  for (let i = 1; i < candles.length; i++) {
    const diff = candles[i].close - candles[i - 1].close
    gains.push(Math.max(0, diff))
    losses.push(Math.max(0, -diff))
  }
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b) / period
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b) / period
  const result = []
  result.push({ time: candles[period].time, value: 100 - 100 / (1 + avgGain / (avgLoss || 0.001)) })
  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period
    const rs = avgGain / (avgLoss || 0.001)
    result.push({ time: candles[i + 1].time, value: 100 - 100 / (1 + rs) })
  }
  return result
}

export function calcBollinger(candles, period = 20, stdDev = 2) {
  const sma = calcSMA(candles, period)
  return sma.map((s, idx) => {
    const slice = candles.slice(idx, idx + period).map(c => c.close)
    const mean = s.value
    const variance = slice.reduce((acc, v) => acc + (v - mean) ** 2, 0) / period
    const std = Math.sqrt(variance)
    return { time: s.time, upper: mean + std * stdDev, middle: mean, lower: mean - std * stdDev }
  })
}

// ─── Price Formatting ─────────────────────────────────────────────────────────

export function formatPrice(price, pair = '') {
  if (price === null || price === undefined) return 'N/A'
  if (pair.includes('DOGE') || pair.includes('ADA') || pair.includes('XRP') || pair.includes('MATIC') || price < 1) {
    return price.toFixed(4)
  }
  if (price < 100) return price.toFixed(2)
  return price.toFixed(2)
}

export function formatVolume(v) {
  if (v >= 1e9) return (v / 1e9).toFixed(1) + 'B'
  if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M'
  if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K'
  return v.toFixed(0)
}

// ─── Market Data ──────────────────────────────────────────────────────────────

export const PAIRS = [
  { symbol: 'BTC/USDT', base: 65000,  icon: '₿', color: '#f7931a' },
  { symbol: 'ETH/USDT', base: 3200,   icon: 'Ξ', color: '#627eea' },
  { symbol: 'BNB/USDT', base: 420,    icon: 'B', color: '#f3ba2f' },
  { symbol: 'SOL/USDT', base: 180,    icon: 'S', color: '#9945ff' },
  { symbol: 'XRP/USDT', base: 0.62,   icon: 'X', color: '#00aae4' },
  { symbol: 'ADA/USDT', base: 0.48,   icon: 'A', color: '#0033ad' },
  { symbol: 'DOGE/USDT',base: 0.16,   icon: 'D', color: '#c3a634' },
  { symbol: 'MATIC/USDT',base: 0.88,  icon: 'M', color: '#8247e5' },
]

export const TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h', '1D']

export function simulateMarketData() {
  return PAIRS.map(p => {
    const chg = (Math.random() - 0.45) * 8
    return {
      ...p,
      price: p.base * (1 + chg / 100),
      change: chg,
      volume: (Math.random() * 2 + 0.5).toFixed(1) + 'B',
      high24h: p.base * (1 + Math.abs(chg) / 100 + 0.01),
      low24h: p.base * (1 - Math.abs(chg) / 100 - 0.005),
    }
  })
}
