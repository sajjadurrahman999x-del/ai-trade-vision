import { NavLink } from 'react-router-dom'

const NAV = [
  { to: '/',        label: '📊 Live Market'  },
  { to: '/analyze', label: '📸 AI Analysis'  },
  { to: '/signals', label: '⚡ Signals'      },
  { to: '/pricing', label: '💎 Plans'        },
]

export default function Navbar() {
  return (
    <header
      className="sticky top-0 z-50 flex items-center justify-between px-4 md:px-6"
      style={{
        height: 52,
        background: '#0d1221',
        borderBottom: '1px solid #1e2d47',
        backdropFilter: 'blur(12px)',
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2.5 select-none">
        <span style={{ fontSize: 20, color: '#00ff88' }}>◈</span>
        <span className="font-bold text-sm tracking-wider hidden sm:block" style={{ color: '#e2e8f0' }}>
          AI TRADE VISION{' '}
          <span style={{ color: '#00aaff' }}>PRO</span>
        </span>
        <span className="font-bold text-sm tracking-wider sm:hidden" style={{ color: '#00aaff' }}>
          ATVP
        </span>
      </div>

      {/* Nav */}
      <nav className="flex items-center gap-1">
        {NAV.map(({ to, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `px-2.5 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
                isActive
                  ? 'text-neon-green'
                  : 'text-slate-400 hover:text-slate-200'
              }`
            }
            style={({ isActive }) =>
              isActive ? { background: 'rgba(0,255,136,0.1)' } : {}
            }
          >
            {label}
          </NavLink>
        ))}
      </nav>

      {/* Live indicator */}
      <div className="flex items-center gap-2">
        <span className="live-dot" />
        <span className="text-slate-500 text-xs hidden sm:inline">Live</span>
      </div>
    </header>
  )
}
