export function SignalBadge({ signal }) {
  const cfg = {
    BUY:  { cls: 'signal-buy',  icon: '▲' },
    SELL: { cls: 'signal-sell', icon: '▼' },
    HOLD: { cls: 'signal-hold', icon: '◆' },
  }[signal] || { cls: 'signal-hold', icon: '◆' }
  return (
    <span className={cfg.cls}>
      {cfg.icon} {signal}
    </span>
  )
}

export function ProbabilityBar({ up, down, confidence }) {
  return (
    <div className="my-3">
      <div className="flex justify-between mb-1.5">
        <span className="text-neon-green font-bold text-lg">▲ {up}%</span>
        <span className="text-slate-400 text-xs">
          Confidence: <span className="text-neon-gold font-semibold">{confidence}%</span>
        </span>
        <span className="text-neon-red font-bold text-lg">{down}% ▼</span>
      </div>
      <div className="h-2.5 rounded-full overflow-hidden flex" style={{ background: '#1a2235' }}>
        <div
          className="transition-all duration-1000 ease-out"
          style={{
            width: `${up}%`,
            background: 'linear-gradient(90deg, #00ff88, #00cc6a)',
          }}
        />
        <div
          className="transition-all duration-1000 ease-out"
          style={{
            width: `${down}%`,
            background: 'linear-gradient(90deg, #cc2244, #ff3b5c)',
          }}
        />
      </div>
    </div>
  )
}

export function RiskMeter({ risk }) {
  const hue = ((100 - risk) * 1.2).toFixed(0)
  const label = risk < 33 ? 'LOW' : risk < 66 ? 'MEDIUM' : 'HIGH'
  return (
    <div className="my-2">
      <div className="flex justify-between mb-1">
        <span className="text-slate-500 text-xs">Risk Level</span>
        <span className="text-xs font-semibold" style={{ color: `hsl(${hue},85%,58%)` }}>
          {label} ({risk}%)
        </span>
      </div>
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#1a2235' }}>
        <div
          className="h-full transition-all duration-700"
          style={{
            width: `${risk}%`,
            background: `linear-gradient(90deg, #00ff88, hsl(${hue},85%,52%))`,
          }}
        />
      </div>
    </div>
  )
}

export function PatternTag({ label }) {
  return <span className="pattern-tag">{label}</span>
}

export function TradeLevel({ label, value, color }) {
  const colorMap = { green: '#00ff88', red: '#ff3b5c', blue: '#00aaff' }
  const c = colorMap[color] || color || '#e2e8f0'
  return (
    <div
      className="rounded-lg p-3"
      style={{ background: '#080c18', border: `1px solid ${c}33` }}
    >
      <div className="text-slate-500 text-xs mb-1">{label}</div>
      <div className="font-bold text-sm" style={{ color: c }}>{value}</div>
    </div>
  )
}

export function MetricRow({ label, value, color }) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-border">
      <span className="text-slate-500 text-xs">{label}</span>
      <span className="font-semibold text-xs" style={{ color: color || '#e2e8f0' }}>{value}</span>
    </div>
  )
}

export default function AnalysisResult({ analysis, onReset }) {
  if (!analysis) return null
  const glowColor = analysis.signal === 'BUY' ? '#00ff88' : analysis.signal === 'SELL' ? '#ff3b5c' : '#ffd700'

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 animate-slideUp">
      {/* Left: Signal + Commentary */}
      <div
        className="card"
        style={{
          boxShadow: `0 0 14px ${glowColor}22`,
          borderColor: `${glowColor}44`,
        }}
      >
        <div className="metric-label">AI Signal</div>
        <div className="my-3"><SignalBadge signal={analysis.signal} /></div>

        {analysis.asset && analysis.asset !== 'Unknown' && (
          <div className="text-xs text-neon-blue mb-1">
            {analysis.asset} · {analysis.timeframe}
          </div>
        )}

        <div className="text-slate-300 text-sm leading-relaxed my-3">
          {analysis.commentary}
        </div>

        {analysis.indicators && (
          <div className="mt-2">
            <MetricRow label="Trend"   value={analysis.trend}
              color={analysis.trend === 'BULLISH' ? '#00ff88' : analysis.trend === 'BEARISH' ? '#ff3b5c' : '#ffd700'} />
            <MetricRow label="RSI"     value={analysis.indicators.rsi} />
            <MetricRow label="MACD"    value={analysis.indicators.macd} />
            <MetricRow label="Volume"  value={analysis.indicators.volume} />
          </div>
        )}

        {analysis.patterns?.length > 0 && (
          <div className="mt-3">
            <div className="metric-label mb-2">Detected Patterns</div>
            {analysis.patterns.map(p => <PatternTag key={p} label={p} />)}
          </div>
        )}

        {onReset && (
          <button onClick={onReset} className="btn-outline mt-4 text-xs">
            ↩ Analyze Another
          </button>
        )}
      </div>

      {/* Right: Probabilities + Levels */}
      <div className="flex flex-col gap-4">
        <div className="card">
          <div className="metric-label">Probability Forecast</div>
          <ProbabilityBar
            up={analysis.upProbability}
            down={analysis.downProbability}
            confidence={analysis.confidence}
          />
          <RiskMeter risk={analysis.riskLevel} />
        </div>

        <div className="card" style={{ background: '#080c18' }}>
          <div className="metric-label mb-3">Trade Levels</div>
          <div className="grid grid-cols-3 gap-2">
            <TradeLevel label="Entry Zone"  value={analysis.entry}      color="blue"  />
            <TradeLevel label="Stop Loss"   value={analysis.stopLoss}   color="red"   />
            <TradeLevel label="Take Profit" value={analysis.takeProfit} color="green" />
          </div>
        </div>

        {analysis.keyLevels && (
          <div className="card">
            <div className="metric-label mb-2">Key Levels</div>
            <MetricRow label="Support"    value={analysis.keyLevels.support}    color="#00ff88" />
            <MetricRow label="Resistance" value={analysis.keyLevels.resistance} color="#ff3b5c" />
            {analysis.smartMoneyConcept && (
              <div className="mt-2 text-xs text-slate-400 italic">{analysis.smartMoneyConcept}</div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
