import { formatPrice } from '../utils/chartUtils'

export default function MarketSidebar({ market, selectedPair, onSelect }) {
  return (
    <aside className="card flex flex-col gap-0 overflow-hidden">
      <div className="metric-label px-1 mb-2">Market Watch</div>
      {market.map(m => (
        <button
          key={m.symbol}
          onClick={() => onSelect(m.symbol)}
          className={`w-full flex justify-between items-center px-2 py-2 rounded transition-all duration-150 text-left ${
            selectedPair === m.symbol
              ? 'bg-neon-green/10 border-l-2 border-neon-green pl-1.5'
              : 'hover:bg-white/5 border-l-2 border-transparent'
          }`}
        >
          <div>
            <div className={`font-semibold text-xs ${selectedPair === m.symbol ? 'text-neon-green' : 'text-slate-200'}`}>
              {m.symbol.split('/')[0]}
            </div>
            <div className="text-slate-500 text-xs">{m.symbol}</div>
          </div>
          <div className="text-right">
            <div className="text-xs font-mono font-medium">
              ${formatPrice(m.price, m.symbol)}
            </div>
            <div className={`text-xs ${m.change >= 0 ? 'text-neon-green' : 'text-neon-red'}`}>
              {m.change >= 0 ? '+' : ''}{m.change.toFixed(2)}%
            </div>
          </div>
        </button>
      ))}
    </aside>
  )
}
