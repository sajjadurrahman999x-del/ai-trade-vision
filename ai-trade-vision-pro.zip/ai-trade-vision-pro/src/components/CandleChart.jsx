import { useMemo } from 'react'
import { calcEMA } from '../utils/chartUtils'

export default function CandleChart({ candles, width = 700, height = 300 }) {
  const data = useMemo(() => {
    if (!candles.length) return null
    const prices = candles.flatMap(c => [c.high, c.low])
    const minP   = Math.min(...prices)
    const maxP   = Math.max(...prices)
    const range  = maxP - minP || 1
    const padL = 65, padR = 10, padT = 14, padB = 28
    const cW = width  - padL - padR
    const cH = height - padT - padB
    const gap = cW / candles.length
    const cw  = Math.max(2, gap - 1.5)

    const toY = p => padT + cH - ((p - minP) / range) * cH
    const toX = i => padL + i * gap + gap / 2

    const ema20 = calcEMA(candles, 20)
    const emaPath = ema20.map((e, i) => {
      const idx = candles.length - ema20.length + i
      return `${i === 0 ? 'M' : 'L'}${toX(idx).toFixed(1)},${toY(e.value).toFixed(1)}`
    }).join(' ')

    const priceLines = [0, 0.25, 0.5, 0.75, 1].map(t => ({
      y: padT + cH * t,
      price: maxP - t * range,
    }))

    return { minP, maxP, range, padL, padR, padT, padB, cW, cH, gap, cw, toY, toX, ema20, emaPath, priceLines }
  }, [candles, width, height])

  if (!data || !candles.length) return null
  const { padL, padT, padB, padR, cW, cH, gap, cw, toY, toX, emaPath, priceLines } = data
  const last = candles[candles.length - 1]

  return (
    <svg
      width="100%"
      viewBox={`0 0 ${width} ${height}`}
      style={{ display: 'block', background: '#080c18', borderRadius: 8 }}
      aria-label="Candlestick price chart"
    >
      {/* Grid lines */}
      {priceLines.map(({ y, price }, i) => (
        <g key={i}>
          <line x1={padL} y1={y} x2={width - padR} y2={y}
            stroke="#1e2d47" strokeWidth="0.5" strokeDasharray="4,5" />
          <text x={padL - 6} y={y + 3.5} fill="#4a5568" fontSize="9" textAnchor="end">
            {price >= 1000 ? price.toFixed(0) : price >= 1 ? price.toFixed(2) : price.toFixed(4)}
          </text>
        </g>
      ))}

      {/* EMA 20 */}
      {emaPath && (
        <path d={emaPath} fill="none" stroke="#00aaff" strokeWidth="1.5" opacity="0.65" />
      )}

      {/* Candles */}
      {candles.map((c, i) => {
        const x       = toX(i)
        const isGreen = c.close >= c.open
        const color   = isGreen ? '#00ff88' : '#ff3b5c'
        const bodyTop = toY(Math.max(c.open, c.close))
        const bodyH   = Math.max(1.5, Math.abs(toY(c.open) - toY(c.close)))

        return (
          <g key={i}>
            <line x1={x} y1={toY(c.high)} x2={x} y2={toY(c.low)}
              stroke={color} strokeWidth="1" opacity="0.7" />
            <rect
              x={x - cw / 2} y={bodyTop}
              width={cw} height={bodyH}
              fill={color} opacity={isGreen ? 0.85 : 0.9}
              rx="0.5"
            />
          </g>
        )
      })}

      {/* Current price label */}
      <rect
        x={width - padR - 64} y={toY(last.close) - 9}
        width={60} height={16} rx="3"
        fill={last.close >= candles[candles.length - 2]?.close ? '#00ff8822' : '#ff3b5c22'}
        stroke={last.close >= candles[candles.length - 2]?.close ? '#00ff8866' : '#ff3b5c66'}
        strokeWidth="0.5"
      />
      <text
        x={width - padR - 34} y={toY(last.close) + 3.5}
        fill={last.close >= candles[candles.length - 2]?.close ? '#00ff88' : '#ff3b5c'}
        fontSize="9" fontWeight="600" textAnchor="middle" fontFamily="monospace"
      >
        {last.close >= 1000
          ? last.close.toFixed(2)
          : last.close >= 1
            ? last.close.toFixed(3)
            : last.close.toFixed(5)}
      </text>

      {/* EMA legend */}
      <circle cx={padL + 6} cy={padT + 8} r="4" fill="#00aaff" opacity="0.7" />
      <text x={padL + 14} y={padT + 12} fill="#4a6a8a" fontSize="9">EMA 20</text>
    </svg>
  )
}
