# AI Trade Vision Pro 🚀

> AI-Powered Crypto Trading Chart Analysis Platform

A professional-grade trading dashboard with real-time candlestick charts, AI-powered pattern detection, and signal generation using Claude Vision AI.

---

## ✨ Features

- 📊 **Live Market Dashboard** — Real-time candlestick charts with EMA overlay, 8 pairs, 6 timeframes
- 📸 **AI Screenshot Analysis** — Upload any chart image; Claude Vision analyzes patterns, signals, levels
- ⚡ **AI Signals Feed** — Pattern-detected buy/sell/hold signals with probability meters
- 💎 **Pricing Plans** — Free / Pro / VIP tier structure
- 📱 **PWA Ready** — Installable on Android and iOS
- 🌙 **Cyberpunk Dark UI** — Professional fintech aesthetic

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Set environment variables
```bash
cp .env.example .env
# Edit .env and add your API keys
```

### 3. Run development server
```bash
npm run dev
# → http://localhost:3000
```

### 4. Build for production
```bash
npm run build
# → /dist folder
```

---

## 🔑 Environment Variables

| Variable | Required | Description |
|---|---|---|
| `VITE_ANTHROPIC_API_KEY` | ✅ Yes | Your Anthropic API key (get at console.anthropic.com) |
| `VITE_BINANCE_API_KEY` | Optional | Binance API key for live data |
| `VITE_TELEGRAM_BOT_TOKEN` | Optional | Telegram bot for signal alerts |

> ⚠️ Without `VITE_ANTHROPIC_API_KEY`, the app runs in **demo mode** with mock analysis.

---

## ☁️ Deploy to Vercel (Free)

### Option A: Vercel CLI
```bash
npm install -g vercel
vercel login
vercel --prod
```

### Option B: Vercel Dashboard
1. Push your code to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. Add environment variables in the Vercel dashboard:
   - `VITE_ANTHROPIC_API_KEY` → your key
5. Click **Deploy** ✅

### Option C: One-click deploy
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

The included `vercel.json` handles:
- SPA routing (all paths → `index.html`)
- Asset caching headers
- Vite framework preset

---

## 📁 Project Structure

```
ai-trade-vision-pro/
├── public/
│   ├── favicon.svg
│   └── manifest.json          # PWA manifest
├── src/
│   ├── components/
│   │   ├── Navbar.jsx          # Top navigation
│   │   ├── CandleChart.jsx     # SVG candlestick chart
│   │   ├── MarketSidebar.jsx   # Pair list sidebar
│   │   └── AnalysisResult.jsx  # Shared AI result display
│   ├── hooks/
│   │   └── useMarket.js        # Market data + live tick hook
│   ├── pages/
│   │   ├── Dashboard.jsx       # Live chart + AI analysis
│   │   ├── Analyze.jsx         # Screenshot upload page
│   │   ├── Signals.jsx         # Signal feed
│   │   └── Pricing.jsx         # Plans page
│   ├── utils/
│   │   ├── aiService.js        # Anthropic API calls
│   │   └── chartUtils.js       # Candle generation + indicators
│   ├── App.jsx                 # Router
│   ├── main.jsx                # React entry
│   └── index.css               # Tailwind + global styles
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── vercel.json
└── .env.example
```

---

## 🔧 Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 18 + Vite 5 |
| Routing | React Router v6 |
| Styling | Tailwind CSS v3 |
| Charts | Custom SVG (no deps) |
| Animation | Framer Motion |
| AI | Claude claude-sonnet-4-20250514 (Vision) |
| Icons | Lucide React |
| Deployment | Vercel |

---

## 🛠️ Extending the App

### Add Binance WebSocket (live prices)
```js
// In useMarket.js, replace the interval with:
const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${pair.toLowerCase()}@kline_${tf}`)
ws.onmessage = (e) => {
  const { k } = JSON.parse(e.data)
  // Update candles with k.o, k.h, k.l, k.c
}
```

### Add Telegram alerts
```js
// Send signal to your bot:
fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`, {
  method: 'POST',
  body: JSON.stringify({ chat_id: CHAT_ID, text: `🚀 BUY signal on ${pair}...`, parse_mode: 'HTML' })
})
```

### Add user authentication
- Install: `npm install firebase`
- Use Firebase Auth with Google sign-in
- Store analysis history in Firestore

---

## ⚠️ Disclaimer

This platform provides AI-generated market analysis and does not guarantee financial accuracy. Trading cryptocurrency and other financial instruments involves significant risk of loss. This is not financial advice. Never invest more than you can afford to lose. Always conduct your own research.

---

## 📄 License

MIT — free for personal and commercial use.
